<?php

namespace Inventa\ExampleFormBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class InventaExampleFormBundle extends Bundle
{
}
