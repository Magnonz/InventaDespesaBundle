<?php

/* InventaExampleFormBundle:Default:index.html.twig */
class __TwigTemplate_37763753cebbe2a48789416381457eb6e5c050f9ecb706e0047699b5d3d7d6db extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<html>
<head>
<title>Agenda</title>

</head>
<body>
<h1>Agenda</h1>
<div class=\"container\">


";
        // line 11
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getContext($context, "tarefa"));
        foreach ($context['_seq'] as $context["_key"] => $context["task"]) {
            // line 12
            echo "
\t<p>";
            // line 13
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "task"), "task"), "html", null, true);
            echo " no dia ";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getContext($context, "task"), "dueDate"), "m/d/Y"), "html", null, true);
            echo "</p>

";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['task'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        echo "


</div>
</body>


</html>";
    }

    public function getTemplateName()
    {
        return "InventaExampleFormBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 16,  38 => 13,  35 => 12,  31 => 11,  19 => 1,);
    }
}
