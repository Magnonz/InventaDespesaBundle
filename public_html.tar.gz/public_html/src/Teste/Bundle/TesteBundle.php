<?php

namespace Teste\Bundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TesteBundle extends Bundle
{
}
