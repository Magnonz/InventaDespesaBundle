<?php

/* InventaExampleFormBundle:Default:insert.html.twig */
class __TwigTemplate_efc904ac4fe18c43697fe6ef4f5c1cf55d7b07fc92e3abf53ad77597023d3a8b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h1>Agenda</h1>


";
        // line 4
        echo         $this->env->getExtension('form')->renderer->renderBlock($this->getContext($context, "form"), 'form');
    }

    public function getTemplateName()
    {
        return "InventaExampleFormBundle:Default:insert.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  24 => 4,  19 => 1,);
    }
}
